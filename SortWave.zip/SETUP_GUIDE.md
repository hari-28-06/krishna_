# 🎵 SortWave V2 — Setup Guide
## ACRCloud + Claude AI (Spotify లేదు!)

---

## API Keys నీకు కావలసినవి

1. ACRCloud Key (Song Recognition) — Free
2. Claude API Key (AI Analysis) — Free $5 credits

---

## PART 1: Claude API Key తీసుకో

1. https://console.anthropic.com వెళ్ళు
2. "Sign Up" చేయి
3. Email verify చేయి
4. Dashboard లో "Get API Keys" click చేయి
5. "Create Key" click చేయి
6. Key copy చేసి save చేయి ✅

---

## PART 2: ACRCloud Key తీసుకో

1. https://www.acrcloud.com వెళ్ళు
2. Sign Up చేయి
3. Console → Create Project
   - Type: Audio & Video Recognition
   - Region: Asia (Singapore)
4. Host + Access Key + Secret copy చేయి ✅

---

## PART 3: Keys పెట్టు

lib/api_service.dart లో top లో:

const String ACR_HOST = 'నీ host ఇక్కడ';
const String ACR_ACCESS_KEY = 'నీ key ఇక్కడ';
const String ACR_ACCESS_SECRET = 'నీ secret ఇక్కడ';
const String CLAUDE_API_KEY = 'నీ claude key ఇక్కడ';

---

## PART 4: FlutLab లో Build చేయి

1. flutlab.io → New Project → Blank
2. ఈ files replace/create చేయి:
   - pubspec.yaml
   - lib/main.dart
   - lib/database_helper.dart
   - lib/api_service.dart
   - android/app/src/main/AndroidManifest.xml
3. Build → Android APK → Download ✅

---

## Cost Summary

| Tool | Cost |
|------|------|
| ACRCloud | Free (1000 songs/month) |
| Claude API | Free ($5 credits = 5000 songs) |
| FlutLab | Free |
| TOTAL | ₹0 to start! |
