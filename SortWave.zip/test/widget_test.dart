import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sortwave/main.dart';

void main() {
  testWidgets('SortWave smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const SortWaveApp());
    expect(find.text('SortWave'), findsOneWidget);
  });
}
