import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:just_audio/just_audio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'database_helper.dart';
import 'api_service.dart';

void main() => runApp(const SortWaveApp());

const Map<String, Color> PLAYLIST_COLORS = {
  'Happy 😄': Color(0xFFFFD700),
  'Sad 😢': Color(0xFF4FC3F7),
  'Chill 😌': Color(0xFF80CBC4),
  'Energetic ⚡': Color(0xFFFF6B35),
  'Romantic 💕': Color(0xFFF48FB1),
  'Angry 😤': Color(0xFFFF5252),
  'Pop 🎤': Color(0xFFCE93D8),
  'Rock 🎸': Color(0xFFFF8A65),
  'Classical 🎻': Color(0xFFA5D6A7),
  'Hip-Hop 🎧': Color(0xFFFFD54F),
  'Folk 🪕': Color(0xFFFFCC80),
  'EDM 🎛️': Color(0xFF80DEEA),
  'Telugu 🇮🇳': Color(0xFFEF9A9A),
  'Hindi 🇮🇳': Color(0xFFFFF59D),
  'English 🌍': Color(0xFFB3E5FC),
  'Tamil 🎶': Color(0xFFF8BBD9),
  'Mixed 🎵': Color(0xFFDCEDC8),
};

const List<String> ALL_PLAYLISTS = [
  'Happy 😄', 'Sad 😢', 'Chill 😌', 'Energetic ⚡', 'Romantic 💕', 'Angry 😤',
  'Pop 🎤', 'Rock 🎸', 'Classical 🎻', 'Hip-Hop 🎧', 'Folk 🪕', 'EDM 🎛️',
  'Telugu 🇮🇳', 'Hindi 🇮🇳', 'English 🌍', 'Tamil 🎶', 'Mixed 🎵',
];

class SortWaveApp extends StatelessWidget {
  const SortWaveApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SortWave',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFA78BFA),
          secondary: Color(0xFF60A5FA),
          surface: Color(0xFF0D0D1F),
          background: Color(0xFF05050E),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _audioQuery = OnAudioQuery();
  final _db = DatabaseHelper.instance;
  final _api = ApiService();
  final _player = AudioPlayer();

  int _tab = 0;
  String? _selectedPlaylist;
  List<Map<String, dynamic>> _songs = [];
  Map<String, int> _counts = {};
  bool _analyzing = false;
  String _analyzingName = '';
  int _analyzingDone = 0;
  int _analyzingTotal = 0;
  Map<String, dynamic>? _currentSong;
  bool _isPlaying = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  @override
  void initState() {
    super.initState();
    _init();
    _player.positionStream.listen((p) => setState(() => _position = p));
    _player.durationStream.listen((d) => setState(() => _duration = d ?? Duration.zero));
    _player.playerStateStream.listen((s) => setState(() => _isPlaying = s.playing));
  }

  Future<void> _init() async {
    await Permission.storage.request();
    await Permission.audio.request();
    await _loadDB();
    await _syncSongs();
  }

  Future<void> _loadDB() async {
    final songs = await _db.getAllSongs();
    final counts = await _db.getPlaylistCounts();
    setState(() { _songs = songs; _counts = counts; });
  }

  Future<void> _syncSongs() async {
    final deviceSongs = await _audioQuery.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
    );
    for (final s in deviceSongs) {
      final path = s.data ?? '';
      if (path.isEmpty) continue;
      if (!await _db.isSongAnalyzed(path)) {
        await _db.upsertSong({
          'song_path': path,
          'song_title': s.title,
          'artist': s.artist ?? 'Unknown',
          'analyzed': 0,
        });
      }
    }
    await _loadDB();
    _analyzeNew();
  }

  Future<void> _analyzeNew() async {
    final unanalyzed = await _db.getUnanalyzedSongs();
    if (unanalyzed.isEmpty) return;
    setState(() {
      _analyzing = true;
      _analyzingTotal = unanalyzed.length;
      _analyzingDone = 0;
    });
    for (final song in unanalyzed) {
      final path = song['song_path'] as String;
      final title = song['song_title'] as String;
      setState(() { _analyzingName = title; _analyzingDone++; });
      try {
        final result = await _api.analyzeSong(path, title);
        await _db.markAnalyzed(path, result.mood, result.genre, result.language, result.playlists.join(','));
      } catch (_) {
        await _db.markAnalyzed(path, 'Chill 😌', 'Pop 🎤', 'Mixed 🎵', 'Chill 😌,Pop 🎤,Mixed 🎵');
      }
      await _loadDB();
    }
    setState(() => _analyzing = false);
  }

  Future<void> _play(Map<String, dynamic> song) async {
    try {
      await _player.setFilePath(song['song_path']);
      await _player.play();
      setState(() { _currentSong = song; _tab = 2; });
    } catch (_) {}
  }

  List<Map<String, dynamic>> get _filtered {
    final analyzed = _songs.where((s) => s['analyzed'] == 1).toList();
    if (_selectedPlaylist == null) return analyzed;
    return analyzed.where((s) => (s['playlists'] as String? ?? '').contains(_selectedPlaylist!)).toList();
  }

  @override
  void dispose() { _player.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF05050E),
      body: Stack(children: [
        // BG
        Container(decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.8, -0.8), radius: 1.2,
            colors: [Color(0xFF1A0A3A), Color(0xFF05050E)],
          ),
        )),
        SafeArea(child: Column(children: [
          _header(),
          if (_analyzing) _banner(),
          Expanded(child: IndexedStack(index: _tab, children: [
            _playlistsTab(),
            _songsTab(),
            _nowPlayingTab(),
          ])),
          _bottomNav(),
        ])),
      ]),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
    child: Row(children: [
      ShaderMask(
        shaderCallback: (b) => const LinearGradient(
          colors: [Color(0xFFC4B5FD), Color(0xFF93C5FD), Color(0xFF6EE7B7)],
        ).createShader(b),
        child: const Text('♪ SortWave', style: TextStyle(
          fontSize: 26, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: -1,
        )),
      ),
      const Spacer(),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: const Color(0xFF1A1A40), borderRadius: BorderRadius.circular(20)),
        child: Text('${_songs.where((s) => s['analyzed'] == 1).length} songs',
            style: const TextStyle(fontSize: 11, color: Color(0xFF6060AA))),
      ),
    ]),
  );

  Widget _banner() => Container(
    margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    decoration: BoxDecoration(
      color: const Color(0xFF1A0A3A),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: const Color(0xFF6D28D9)),
    ),
    child: Row(children: [
      const SizedBox(width: 16, height: 16,
        child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFA78BFA))),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Analyzing $_analyzingDone/$_analyzingTotal...',
          style: const TextStyle(fontSize: 11, color: Color(0xFFA78BFA), fontWeight: FontWeight.bold)),
        Text(_analyzingName,
          style: const TextStyle(fontSize: 10, color: Color(0xFF3A3A7A)),
          overflow: TextOverflow.ellipsis),
      ])),
    ]),
  );

  // ─── PLAYLISTS TAB ───
  Widget _playlistsTab() {
    final active = ALL_PLAYLISTS.where((p) => (_counts[p] ?? 0) > 0).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 20, 16, 80), children: [
      if (active.isNotEmpty) ...[
        _sectionLabel('ACTIVE PLAYLISTS'),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, childAspectRatio: 1.5, crossAxisSpacing: 10, mainAxisSpacing: 10),
          itemCount: active.length,
          itemBuilder: (_, i) => _playlistCard(active[i], _counts[active[i]] ?? 0, large: true),
        ),
        const SizedBox(height: 24),
      ],
      _sectionLabel('ALL CATEGORIES'),
      const SizedBox(height: 12),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, childAspectRatio: 1.1, crossAxisSpacing: 8, mainAxisSpacing: 8),
        itemCount: ALL_PLAYLISTS.length,
        itemBuilder: (_, i) => _playlistCard(ALL_PLAYLISTS[i], _counts[ALL_PLAYLISTS[i]] ?? 0),
      ),
    ]);
  }

  Widget _sectionLabel(String label) => Text(label,
    style: TextStyle(fontSize: 10, letterSpacing: 3, color: Colors.white.withOpacity(0.25)));

  Widget _playlistCard(String pl, int count, {bool large = false}) {
    final emoji = _emoji(pl);
    final color = PLAYLIST_COLORS[pl] ?? const Color(0xFFA78BFA);
    return GestureDetector(
      onTap: count > 0 ? () { setState(() { _selectedPlaylist = pl; _tab = 1; }); } : null,
      child: Container(
        decoration: BoxDecoration(
          color: count > 0 ? color.withOpacity(0.08) : const Color(0xFF0A0A20),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: count > 0 ? color.withOpacity(0.3) : const Color(0xFF0F0F30)),
        ),
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(emoji, style: TextStyle(fontSize: large ? 26 : 22)),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(pl.split(' ')[0], style: TextStyle(
              fontSize: large ? 12 : 10, fontWeight: FontWeight.w900,
              color: count > 0 ? color : const Color(0xFF2A2A5A), letterSpacing: 0.5)),
            Text('$count songs', style: TextStyle(
              fontSize: 10, color: count > 0 ? color.withOpacity(0.7) : const Color(0xFF1A1A3A))),
          ]),
        ]),
      ),
    );
  }

  // ─── SONGS TAB ───
  Widget _songsTab() {
    final songs = _filtered;
    return Column(children: [
      if (_selectedPlaylist != null)
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: (PLAYLIST_COLORS[_selectedPlaylist] ?? const Color(0xFFA78BFA)).withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: (PLAYLIST_COLORS[_selectedPlaylist] ?? const Color(0xFFA78BFA)).withOpacity(0.4)),
              ),
              child: Text(_selectedPlaylist!, style: TextStyle(
                fontSize: 12, color: PLAYLIST_COLORS[_selectedPlaylist] ?? const Color(0xFFA78BFA))),
            ),
            const SizedBox(width: 8),
            GestureDetector(onTap: () => setState(() => _selectedPlaylist = null),
              child: const Icon(Icons.close, color: Color(0xFF3A3A7A), size: 18)),
            const Spacer(),
            Text('${songs.length} songs', style: const TextStyle(fontSize: 11, color: Color(0xFF2A2A5A))),
          ]),
        ),
      Expanded(
        child: songs.isEmpty
          ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('🎵', style: TextStyle(fontSize: 48, color: Colors.white.withOpacity(0.08))),
              const SizedBox(height: 12),
              Text(_analyzing ? 'Songs analyze అవుతున్నాయి...' : 'Songs లేవు',
                style: const TextStyle(color: Color(0xFF1A1A3A), fontSize: 12, letterSpacing: 2)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 80),
              itemCount: songs.length,
              itemBuilder: (_, i) {
                final song = songs[i];
                final playing = _currentSong?['song_path'] == song['song_path'] && _isPlaying;
                return _songRow(song, i, playing);
              },
            ),
      ),
    ]);
  }

  Widget _songRow(Map<String, dynamic> song, int i, bool playing) {
    final mood = song['mood'] as String? ?? 'Chill 😌';
    final color = PLAYLIST_COLORS[mood] ?? const Color(0xFFA78BFA);
    final pls = (song['playlists'] as String? ?? '').split(',').where((p) => p.trim().isNotEmpty).toList();
    return GestureDetector(
      onTap: () => _play(song),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: playing ? color.withOpacity(0.1) : const Color(0xFF0A0A20),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: playing ? color.withOpacity(0.4) : const Color(0xFF0F0F30)),
        ),
        child: Row(children: [
          Container(width: 36, height: 36,
            decoration: BoxDecoration(
              color: playing ? color.withOpacity(0.2) : const Color(0xFF0F0F30),
              borderRadius: BorderRadius.circular(10)),
            child: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
              color: playing ? color : const Color(0xFF3A3A7A), size: 20)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(song['song_title'] ?? 'Unknown', style: TextStyle(
              fontSize: 13, fontWeight: FontWeight.w700,
              color: playing ? Colors.white : const Color(0xFFB0B0E0)),
              overflow: TextOverflow.ellipsis),
            const SizedBox(height: 2),
            Text(song['artist'] ?? '', style: const TextStyle(fontSize: 10, color: Color(0xFF2A2A5A)),
              overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Wrap(spacing: 4, children: pls.take(3).map((pl) {
              final c = PLAYLIST_COLORS[pl.trim()] ?? const Color(0xFF3A3A7A);
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                decoration: BoxDecoration(
                  color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: c.withOpacity(0.3))),
                child: Text(pl.trim().split(' ')[0], style: TextStyle(fontSize: 9, color: c)));
            }).toList()),
          ])),
          Container(width: 8, height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)])),
        ]),
      ),
    );
  }

  // ─── NOW PLAYING TAB ───
  Widget _nowPlayingTab() {
    if (_currentSong == null) {
      return const Center(child: Text('ఏ song ఇంకా play కాలేదు',
        style: TextStyle(color: Color(0xFF1A1A3A), letterSpacing: 2)));
    }
    final mood = _currentSong!['mood'] as String? ?? 'Chill 😌';
    final color = PLAYLIST_COLORS[mood] ?? const Color(0xFFA78BFA);
    final pls = (_currentSong!['playlists'] as String? ?? '').split(',').where((p) => p.trim().isNotEmpty).toList();

    return Padding(padding: const EdgeInsets.all(24), child: Column(children: [
      const SizedBox(height: 20),
      // Album art
      Container(width: 220, height: 220,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: RadialGradient(colors: [color.withOpacity(0.3), const Color(0xFF05050E)]),
          border: Border.all(color: color.withOpacity(0.2)),
          boxShadow: [BoxShadow(color: color.withOpacity(0.2), blurRadius: 40, spreadRadius: 5)]),
        child: Center(child: Text('🎵',
          style: TextStyle(fontSize: 72, shadows: [Shadow(color: color, blurRadius: 20)])))),
      const SizedBox(height: 32),
      Text(_currentSong!['song_title'] ?? 'Unknown', textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white),
        maxLines: 2, overflow: TextOverflow.ellipsis),
      const SizedBox(height: 6),
      Text(_currentSong!['artist'] ?? '',
        style: const TextStyle(fontSize: 13, color: Color(0xFF4040AA))),
      const SizedBox(height: 16),
      Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center,
        children: pls.map((pl) {
          final c = PLAYLIST_COLORS[pl.trim()] ?? const Color(0xFF3A3A7A);
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(20),
              border: Border.all(color: c.withOpacity(0.3))),
            child: Text(pl.trim(), style: TextStyle(fontSize: 11, color: c)));
        }).toList()),
      const Spacer(),
      // Progress
      SliderTheme(
        data: SliderTheme.of(context).copyWith(
          activeTrackColor: color, inactiveTrackColor: color.withOpacity(0.2),
          thumbColor: color, overlayColor: color.withOpacity(0.1),
          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6), trackHeight: 3),
        child: Slider(
          value: _duration.inMilliseconds > 0
            ? (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0) : 0.0,
          onChanged: (v) => _player.seek(Duration(milliseconds: (v * _duration.inMilliseconds).round())),
        ),
      ),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(_fmt(_position), style: const TextStyle(fontSize: 11, color: Color(0xFF3A3A7A))),
          Text(_fmt(_duration), style: const TextStyle(fontSize: 11, color: Color(0xFF3A3A7A))),
        ])),
      const SizedBox(height: 16),
      // Controls
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(icon: const Icon(Icons.skip_previous_rounded), iconSize: 36,
          color: const Color(0xFF4040AA), onPressed: () {}),
        const SizedBox(width: 16),
        GestureDetector(
          onTap: () => _isPlaying ? _player.pause() : _player.play(),
          child: Container(width: 64, height: 64,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: LinearGradient(colors: [color, color.withOpacity(0.6)]),
              boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 20)]),
            child: Icon(_isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
              color: Colors.white, size: 32))),
        const SizedBox(width: 16),
        IconButton(icon: const Icon(Icons.skip_next_rounded), iconSize: 36,
          color: const Color(0xFF4040AA), onPressed: () {}),
      ]),
      const SizedBox(height: 20),
    ]));
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String _emoji(String pl) {
    final map = {'😄':'😄','😢':'😢','😌':'😌','⚡':'⚡','💕':'💕','😤':'😤',
      '🎤':'🎤','🎸':'🎸','🎻':'🎻','🎧':'🎧','🪕':'🪕','🎛️':'🎛️',
      '🇮🇳':'🇮🇳','🌍':'🌍','🎶':'🎶','🎵':'🎵'};
    for (final e in map.keys) { if (pl.contains(e)) return e; }
    return '🎵';
  }

  Widget _bottomNav() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
    decoration: const BoxDecoration(color: Color(0xFF08081A),
      border: Border(top: BorderSide(color: Color(0xFF0F0F30)))),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _navItem(0, Icons.grid_view_rounded, 'Playlists'),
        _navItem(1, Icons.music_note_rounded, 'Songs'),
        _navItem(2, Icons.equalizer_rounded, 'Playing'),
      ]),
  );

  Widget _navItem(int i, IconData icon, String label) {
    final active = _tab == i;
    return GestureDetector(
      onTap: () => setState(() => _tab = i),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: active ? const Color(0xFFA78BFA) : const Color(0xFF2A2A5A), size: 22),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 10, letterSpacing: 1,
          color: active ? const Color(0xFFA78BFA) : const Color(0xFF2A2A5A))),
      ]),
    );
  }
}
