import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

// =============================================
// 🔑 ONLY ACRCloud KEYS NEEDED — 100% FREE!
// =============================================
const String ACR_HOST = 'identify-ap-southeast-1.acrcloud.com';
const String ACR_ACCESS_KEY = '5f5777945057ad79e6e5290ed3db654d';
const String ACR_ACCESS_SECRET = 'Wqo3L1sRnf9zQiHwVZj3qrC0FJkdUyDjWQgrJ5iV';
// =============================================

class AnalysisResult {
  final String mood;
  final String genre;
  final String language;
  final List<String> playlists;
  final String songTitle;
  final String artist;
  final String reason;

  AnalysisResult({
    required this.mood,
    required this.genre,
    required this.language,
    required this.playlists,
    required this.songTitle,
    required this.artist,
    required this.reason,
  });
}

class ApiService {
  // ─── ACRCloud: Audio Fingerprint తో Song Identify ───
  Future<Map<String, dynamic>?> identifySong(String filePath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) return null;

      final bytes = await file.readAsBytes();
      final sample = bytes.length > 200000 ? bytes.sublist(0, 200000) : bytes;

      final timestamp =
          (DateTime.now().millisecondsSinceEpoch / 1000).floor().toString();
      final reqUrl = 'https://$ACR_HOST/v1/identify';

      final stringToSign =
          'POST\n/v1/identify\n$ACR_ACCESS_KEY\naudio\n1\n$timestamp';
      final hmac = Hmac(sha1, utf8.encode(ACR_ACCESS_SECRET));
      final signature =
          base64.encode(hmac.convert(utf8.encode(stringToSign)).bytes);

      final request = http.MultipartRequest('POST', Uri.parse(reqUrl));
      request.fields['access_key'] = ACR_ACCESS_KEY;
      request.fields['sample_bytes'] = sample.length.toString();
      request.fields['timestamp'] = timestamp;
      request.fields['signature'] = signature;
      request.fields['data_type'] = 'audio';
      request.fields['signature_version'] = '1';
      request.files.add(http.MultipartFile.fromBytes('sample', sample,
          filename: 'sample.mp3'));

      final response =
          await request.send().timeout(const Duration(seconds: 20));
      final body = await response.stream.bytesToString();
      final json = jsonDecode(body);

      if (json['status']['code'] == 0) {
        final music = json['metadata']['music'][0];
        return {
          'title': music['title'] ?? '',
          'artist': music['artists']?[0]['name'] ?? '',
          'album': music['album']?['name'] ?? '',
          'genres': (music['genres'] as List?)
                  ?.map((g) => g['name'].toString())
                  .toList() ??
              [],
          'tempo': (music['tempo'] ?? 0.0).toDouble(),
          'mood': music['mood']?['mood'] ?? '',
        };
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ─── Genre Classify ───
  String _classifyGenre(List<String> genres) {
    if (genres.isEmpty) return 'Pop 🎤';
    final g = genres.join(' ').toLowerCase();
    if (g.contains('rock') || g.contains('metal') || g.contains('punk'))
      return 'Rock 🎸';
    if (g.contains('classical') ||
        g.contains('carnatic') ||
        g.contains('instrumental') ||
        g.contains('orchestra')) return 'Classical 🎻';
    if (g.contains('hip') || g.contains('rap') || g.contains('trap'))
      return 'Hip-Hop 🎧';
    if (g.contains('folk') ||
        g.contains('devotional') ||
        g.contains('bhajan') ||
        g.contains('traditional')) return 'Folk 🪕';
    if (g.contains('edm') ||
        g.contains('electronic') ||
        g.contains('dance') ||
        g.contains('techno')) return 'EDM 🎛️';
    return 'Pop 🎤';
  }

  // ─── Mood Classify ───
  String _classifyMood(
      {String? acrMood,
      double? tempo,
      String? title,
      String? artist,
      required String fileName}) {
    if (acrMood != null && acrMood.isNotEmpty) {
      final m = acrMood.toLowerCase();
      if (m.contains('happy') || m.contains('joy') || m.contains('excited'))
        return 'Happy 😄';
      if (m.contains('sad') ||
          m.contains('melanchol') ||
          m.contains('depressed')) return 'Sad 😢';
      if (m.contains('calm') || m.contains('chill') || m.contains('relax'))
        return 'Chill 😌';
      if (m.contains('energet') ||
          m.contains('upbeat') ||
          m.contains('powerful')) return 'Energetic ⚡';
      if (m.contains('romantic') || m.contains('love') || m.contains('tender'))
        return 'Romantic 💕';
      if (m.contains('angry') || m.contains('aggress') || m.contains('intense'))
        return 'Angry 😤';
    }

    if (tempo != null && tempo > 0) {
      if (tempo > 140) return 'Energetic ⚡';
      if (tempo > 120) return 'Happy 😄';
      if (tempo < 70) return 'Sad 😢';
      if (tempo < 90) return 'Chill 😌';
    }

    final lower =
        '${fileName.toLowerCase()} ${(title ?? '').toLowerCase()} ${(artist ?? '').toLowerCase()}';
    if (lower.contains('sad') ||
        lower.contains('dukham') ||
        lower.contains('virah') ||
        lower.contains('kanneeru') ||
        lower.contains('cry') ||
        lower.contains('broken')) return 'Sad 😢';
    if (lower.contains('love') ||
        lower.contains('prema') ||
        lower.contains('romantic') ||
        lower.contains('heart') ||
        lower.contains('pyaar') ||
        lower.contains('ishq') ||
        lower.contains('manasu')) return 'Romantic 💕';
    if (lower.contains('happy') ||
        lower.contains('dance') ||
        lower.contains('party') ||
        lower.contains('santhosham') ||
        lower.contains('celebrate')) return 'Happy 😄';
    if (lower.contains('mass') ||
        lower.contains('power') ||
        lower.contains('fight') ||
        lower.contains('energy') ||
        lower.contains('beast') ||
        lower.contains('fire')) return 'Energetic ⚡';
    if (lower.contains('angry') ||
        lower.contains('rage') ||
        lower.contains('war') ||
        lower.contains('destroy')) return 'Angry 😤';
    return 'Chill 😌';
  }

  // ─── Language Classify ───
  String _classifyLanguage(String fileName, String? title, String? artist) {
    final combined = '$fileName ${title ?? ''} ${artist ?? ''}';
    if (RegExp(r'[\u0C00-\u0C7F]').hasMatch(combined)) return 'Telugu 🇮🇳';
    if (RegExp(r'[\u0900-\u097F]').hasMatch(combined)) return 'Hindi 🇮🇳';
    if (RegExp(r'[\u0B80-\u0BFF]').hasMatch(combined)) return 'Tamil 🎶';

    final lower = combined.toLowerCase();
    if (lower.contains('telugu') ||
        lower.contains('tollywood') ||
        lower.contains('nuvvu') ||
        lower.contains('nenu') ||
        lower.contains('manasu') ||
        lower.contains('prema') ||
        lower.contains('oka')) return 'Telugu 🇮🇳';
    if (lower.contains('hindi') ||
        lower.contains('bollywood') ||
        lower.contains('pyaar') ||
        lower.contains('ishq') ||
        lower.contains('dil') ||
        lower.contains('zindagi')) return 'Hindi 🇮🇳';
    if (lower.contains('tamil') ||
        lower.contains('kollywood') ||
        lower.contains('thala') ||
        lower.contains('thalapathy')) return 'Tamil 🎶';

    // Known artists
    final teluguArtists = [
      'sp balasubrahmanyam',
      'sid sriram',
      'anurag kulkarni',
      'harika narayan',
      'rahul sipligunj',
      'dsp',
      'thaman'
    ];
    final hindiArtists = [
      'arijit singh',
      'neha kakkar',
      'atif aslam',
      'shreya ghoshal',
      'jubin nautiyal',
      'darshan raval'
    ];
    for (final a in teluguArtists) {
      if (lower.contains(a)) return 'Telugu 🇮🇳';
    }
    for (final a in hindiArtists) {
      if (lower.contains(a)) return 'Hindi 🇮🇳';
    }

    if (RegExp(r'^[a-zA-Z0-9\s\-_()\[\].,&!]+$')
        .hasMatch(fileName.replaceAll(RegExp(r'\.[^.]+$'), '')))
      return 'English 🌍';
    return 'Mixed 🎵';
  }

  // ─── MAIN: Full Pipeline ───
  Future<AnalysisResult> analyzeSong(String filePath, String fileName) async {
    final acrData = await identifySong(filePath);

    final title = acrData?['title'] as String?;
    final artist = acrData?['artist'] as String?;
    final genres = acrData != null
        ? List<String>.from(acrData['genres'] ?? [])
        : <String>[];
    final tempo = acrData?['tempo'] as double?;
    final acrMood = acrData?['mood'] as String?;

    final mood = _classifyMood(
        acrMood: acrMood,
        tempo: tempo,
        title: title,
        artist: artist,
        fileName: fileName);
    final genre = _classifyGenre(genres);
    final language = _classifyLanguage(fileName, title, artist);

    final playlists = <String>{mood, genre, language};

    // Extra playlists
    if (tempo != null && tempo > 130 && mood != 'Energetic ⚡')
      playlists.add('Energetic ⚡');
    final lowerAll = '${fileName.toLowerCase()} ${(title ?? '').toLowerCase()}';
    if ((lowerAll.contains('love') || lowerAll.contains('prema')) &&
        mood != 'Romantic 💕') playlists.add('Romantic 💕');

    final reason = (acrData != null && title != null && title.isNotEmpty)
        ? 'ACRCloud గుర్తించింది ✅'
        : 'Filename బట్టి classify చేశా';

    return AnalysisResult(
      mood: mood,
      genre: genre,
      language: language,
      playlists: playlists.toList(),
      songTitle: title ?? fileName,
      artist: artist ?? 'Unknown',
      reason: reason,
    );
  }
}
