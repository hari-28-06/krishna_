import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;
  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('sortwave.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE songs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        song_path TEXT UNIQUE NOT NULL,
        song_title TEXT NOT NULL,
        artist TEXT,
        mood TEXT,
        genre TEXT,
        language TEXT,
        playlists TEXT,
        analyzed INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    ''');
  }

  Future<void> upsertSong(Map<String, dynamic> song) async {
    final db = await database;
    await db.insert('songs', song, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> getAllSongs() async {
    final db = await database;
    return await db.query('songs', orderBy: 'song_title ASC');
  }

  Future<List<Map<String, dynamic>>> getSongsByPlaylist(String playlist) async {
    final db = await database;
    return await db.rawQuery(
      "SELECT * FROM songs WHERE playlists LIKE ? AND analyzed = 1",
      ['%$playlist%'],
    );
  }

  Future<List<Map<String, dynamic>>> getUnanalyzedSongs() async {
    final db = await database;
    return await db.query('songs', where: 'analyzed = 0');
  }

  Future<bool> isSongAnalyzed(String path) async {
    final db = await database;
    final result = await db.query('songs',
        where: 'song_path = ? AND analyzed = 1', whereArgs: [path]);
    return result.isNotEmpty;
  }

  Future<void> markAnalyzed(String path, String mood, String genre,
      String language, String playlists) async {
    final db = await database;
    await db.update(
      'songs',
      {'mood': mood, 'genre': genre, 'language': language, 'playlists': playlists, 'analyzed': 1},
      where: 'song_path = ?',
      whereArgs: [path],
    );
  }

  Future<Map<String, int>> getPlaylistCounts() async {
    final db = await database;
    final songs = await db.query('songs', where: 'analyzed = 1');
    Map<String, int> counts = {};
    for (var song in songs) {
      final pls = (song['playlists'] as String? ?? '').split(',');
      for (var pl in pls) {
        final t = pl.trim();
        if (t.isNotEmpty) counts[t] = (counts[t] ?? 0) + 1;
      }
    }
    return counts;
  }
}
